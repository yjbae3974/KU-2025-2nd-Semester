lex problem2_2.l
cc lex.yy.c -o problem2_2 -ll
